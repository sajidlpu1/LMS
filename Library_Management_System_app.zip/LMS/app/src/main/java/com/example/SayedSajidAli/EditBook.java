package com.example.SayedSajidAli;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class EditBook extends AppCompatActivity {

    EditText e1, e2, e3;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editbook);
        e1=findViewById(R.id.et8);
        e2=findViewById(R.id.et9);
        e3=findViewById(R.id.et10);
        b1=findViewById(R.id.bt2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDatabase mdb=new MyDatabase(getApplicationContext());
                mdb.updatestud(e1.getText().toString(),(Long.parseLong(e2.getText().toString())),e3.getText().toString());
                finish();
            }
        });
    }
}
