package com.example.SayedSajidAli;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void addstud(View view) {
        Intent i=new Intent(MainActivity.this, AddBook.class);
        startActivity(i);
    }

    public void viewstud(View view) {
        Intent i2=new Intent(this, AvailableBooks.class);
        startActivity(i2);
    }

    public void update(View view) {
        Intent i3=new Intent(this, EditBook.class);
        startActivity(i3);
    }

    public void search(View view) {
        Intent i4=new Intent(this, SearchBook.class);
        startActivity(i4);
    }

    public void delete(View view) {
        Intent i5=new Intent(this, RemoveBook.class);
        startActivity(i5);
    }
}
