package com.example.SayedSajidAli;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RemoveBook extends AppCompatActivity {

    EditText e1;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_removebook);
        e1=findViewById(R.id.et13);
        b1=findViewById(R.id.bt3);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDatabase mdb=new MyDatabase(getApplicationContext());
                mdb.deletestud(e1.getText().toString());
                finish();
            }
        });
    }
}
