package com.example.SayedSajidAli;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;

public class MyDatabase extends SQLiteOpenHelper {

    private static String dname = "mydatabse";
    private static int version = 1;
    Context ct;

    MyDatabase(Context ct) {
        super(ct, dname, null, version);
        this.ct = ct;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String s = "create table book (bname text, bid integer, bcatg text, bauthor text)";
        db.execSQL(s);
    }

    public void addStud(String s1, long l, String s2, String s3) {
        SQLiteDatabase sdb = getWritableDatabase();
        ContentValues cv1 = new ContentValues();
        cv1.put("bname", s1);
        cv1.put("bid", l);
        cv1.put("bcatg", s2);
        cv1.put("bauthor", s3);
        sdb.insert("book", null, cv1);
        Toast.makeText(ct, "Book Added", Toast.LENGTH_SHORT).show();
    }

    public ArrayList<String> showstud() {
        SQLiteDatabase sdb = getReadableDatabase();
        String s = "select * from book";
        Cursor cr = sdb.rawQuery(s, null);
        ArrayList<String> al = new ArrayList<>();
        while (cr.moveToNext()) {
            String s1 = cr.getString(0);
            long l = cr.getLong(1);
            String s2 = cr.getString(2);
            String s3 = cr.getString(3);
            String s4 = "Book Name :" + s1 + "\nBook Id :" + l + "\nBook Category :" + s2 + "\nAuthor Name :" + s3;
            al.add(s4);
        }
        return al;
    }

    public void updatestud(String s1, long l, String s3) {
        SQLiteDatabase sdb = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("bname", s1);
        cv.put("bid", l);
        cv.put("bcatg", s3);
        String where = "bname = ?";
        String[] ss = {s1};
        sdb.update("book", cv, where, ss);
        Toast.makeText(ct, "Updations Complete", Toast.LENGTH_SHORT).show();
    }

    public ArrayList<String> searhstud(String name) {
        SQLiteDatabase db = getReadableDatabase();
        String s = "select * from book where bname = ?";
        String[] ss = {name};
        Cursor cr = db.rawQuery(s, ss);
        ArrayList<String> al = new ArrayList<>();
        while (cr.moveToNext()) {
            String s1 = cr.getString(0);
            long l = cr.getLong(1);
            String s2 = cr.getString(2);
            String s3 = cr.getString(3);
            String s4 = "Book Name :" + s1 + "\nBook Id :" + l + "\nBook Category :" + s2 + "\nAuthor Name :" + s3;
            al.add(s4);
        }
        return al;
    }

    public void deletestud(String s) {
        SQLiteDatabase sdb = getWritableDatabase();
        String where = "bname = ?";
        String[] ss = {s};
        sdb.delete("book", where, ss);
        Toast.makeText(ct, "Deletion Complete", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
