package com.example.SayedSajidAli;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class SearchBook extends AppCompatActivity {

    ListView lv;
    EditText e1;
    MyDatabase mdb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchbook);
        e1=findViewById(R.id.et7);
        lv=findViewById(R.id.lv2);
        mdb = new MyDatabase(getApplicationContext());
        e1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ArrayList<String> al=mdb.searhstud(s.toString());
                ArrayAdapter ad=new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,al);
                lv.setAdapter(ad);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}
