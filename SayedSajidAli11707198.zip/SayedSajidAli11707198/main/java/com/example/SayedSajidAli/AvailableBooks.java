package com.example.SayedSajidAli;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class AvailableBooks extends AppCompatActivity {

    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_availablebooks);
        lv=findViewById(R.id.lv1);
        MyDatabase mdb=new MyDatabase(getApplicationContext());
        ArrayList<String> s1=mdb.showstud();
        ArrayAdapter<String> ad = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,s1);
        lv.setAdapter(ad);
    }
}
